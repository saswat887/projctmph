﻿namespace Banking_Application
{
    partial class welcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.balance = new System.Windows.Forms.Label();
            this.accname = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Another_Account = new System.Windows.Forms.Button();
            this.Deposit = new System.Windows.Forms.Button();
            this.WithDrawn = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(141, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "WELCOME";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(141, 115);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(225, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Your Account Balance is";
            // 
            // balance
            // 
            this.balance.AutoSize = true;
            this.balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.balance.Location = new System.Drawing.Point(534, 115);
            this.balance.Name = "balance";
            this.balance.Size = new System.Drawing.Size(34, 25);
            this.balance.TabIndex = 2;
            this.balance.Text = "ba";
            // 
            // accname
            // 
            this.accname.AutoSize = true;
            this.accname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.accname.Location = new System.Drawing.Point(534, 56);
            this.accname.Name = "accname";
            this.accname.Size = new System.Drawing.Size(34, 25);
            this.accname.TabIndex = 3;
            this.accname.Text = "na";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(321, 195);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(285, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Please select from below option";
            // 
            // Another_Account
            // 
            this.Another_Account.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Another_Account.Location = new System.Drawing.Point(205, 365);
            this.Another_Account.Name = "Another_Account";
            this.Another_Account.Size = new System.Drawing.Size(178, 42);
            this.Another_Account.TabIndex = 5;
            this.Another_Account.Text = "Another Account";
            this.Another_Account.UseVisualStyleBackColor = true;
            this.Another_Account.Click += new System.EventHandler(this.Another_Account_Click);
            // 
            // Deposit
            // 
            this.Deposit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deposit.Location = new System.Drawing.Point(205, 305);
            this.Deposit.Name = "Deposit";
            this.Deposit.Size = new System.Drawing.Size(178, 36);
            this.Deposit.TabIndex = 6;
            this.Deposit.Text = "Deposit";
            this.Deposit.UseVisualStyleBackColor = true;
            this.Deposit.Click += new System.EventHandler(this.Deposit_Click);
            // 
            // WithDrawn
            // 
            this.WithDrawn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WithDrawn.Location = new System.Drawing.Point(503, 305);
            this.WithDrawn.Name = "WithDrawn";
            this.WithDrawn.Size = new System.Drawing.Size(133, 36);
            this.WithDrawn.TabIndex = 7;
            this.WithDrawn.Text = "Withdrawn";
            this.WithDrawn.UseVisualStyleBackColor = true;
            this.WithDrawn.Click += new System.EventHandler(this.WithDrawn_Click);
            // 
            // Exit
            // 
            this.Exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.Location = new System.Drawing.Point(503, 365);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(133, 42);
            this.Exit.TabIndex = 8;
            this.Exit.Text = "EXIT";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // welcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.WithDrawn);
            this.Controls.Add(this.Deposit);
            this.Controls.Add(this.Another_Account);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.accname);
            this.Controls.Add(this.balance);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "welcome";
            this.Text = "welcome";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label balance;
        private System.Windows.Forms.Label accname;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Another_Account;
        private System.Windows.Forms.Button Deposit;
        private System.Windows.Forms.Button WithDrawn;
        private System.Windows.Forms.Button Exit;
    }
}