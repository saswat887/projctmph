﻿namespace Banking_Application
{
    partial class Withdrawal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Option = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.aname = new System.Windows.Forms.Label();
            this.olddeposit = new System.Windows.Forms.Label();
            this.withamount = new System.Windows.Forms.Label();
            this.newbalance = new System.Windows.Forms.Label();
            this.odamount = new System.Windows.Forms.Label();
            this.depoamount = new System.Windows.Forms.Label();
            this.newbalamount = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Option
            // 
            this.Option.Location = new System.Drawing.Point(229, 337);
            this.Option.Name = "Option";
            this.Option.Size = new System.Drawing.Size(137, 62);
            this.Option.TabIndex = 17;
            this.Option.Text = "Option";
            this.Option.UseVisualStyleBackColor = true;
            this.Option.Click += new System.EventHandler(this.Option_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(470, 337);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(139, 62);
            this.Exit.TabIndex = 16;
            this.Exit.Text = "Exit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // aname
            // 
            this.aname.AutoSize = true;
            this.aname.Location = new System.Drawing.Point(419, 51);
            this.aname.Name = "aname";
            this.aname.Size = new System.Drawing.Size(22, 16);
            this.aname.TabIndex = 15;
            this.aname.Text = "na";
            // 
            // olddeposit
            // 
            this.olddeposit.AutoSize = true;
            this.olddeposit.Location = new System.Drawing.Point(191, 90);
            this.olddeposit.Name = "olddeposit";
            this.olddeposit.Size = new System.Drawing.Size(78, 16);
            this.olddeposit.TabIndex = 14;
            this.olddeposit.Text = "Old Deposit";
            // 
            // withamount
            // 
            this.withamount.AutoSize = true;
            this.withamount.Location = new System.Drawing.Point(191, 145);
            this.withamount.Name = "withamount";
            this.withamount.Size = new System.Drawing.Size(123, 16);
            this.withamount.TabIndex = 13;
            this.withamount.Text = "WithDrawal Amount";
            // 
            // newbalance
            // 
            this.newbalance.AutoSize = true;
            this.newbalance.Location = new System.Drawing.Point(191, 204);
            this.newbalance.Name = "newbalance";
            this.newbalance.Size = new System.Drawing.Size(131, 16);
            this.newbalance.TabIndex = 12;
            this.newbalance.Text = "Your New Balance is";
            // 
            // odamount
            // 
            this.odamount.AutoSize = true;
            this.odamount.Location = new System.Drawing.Point(588, 90);
            this.odamount.Name = "odamount";
            this.odamount.Size = new System.Drawing.Size(21, 16);
            this.odamount.TabIndex = 11;
            this.odamount.Text = "12";
            // 
            // depoamount
            // 
            this.depoamount.AutoSize = true;
            this.depoamount.Location = new System.Drawing.Point(588, 145);
            this.depoamount.Name = "depoamount";
            this.depoamount.Size = new System.Drawing.Size(21, 16);
            this.depoamount.TabIndex = 10;
            this.depoamount.Text = "12";
            // 
            // newbalamount
            // 
            this.newbalamount.AutoSize = true;
            this.newbalamount.Location = new System.Drawing.Point(588, 204);
            this.newbalamount.Name = "newbalamount";
            this.newbalamount.Size = new System.Drawing.Size(21, 16);
            this.newbalamount.TabIndex = 9;
            this.newbalamount.Text = "12";
            // 
            // Withdrawal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.Option);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.aname);
            this.Controls.Add(this.olddeposit);
            this.Controls.Add(this.withamount);
            this.Controls.Add(this.newbalance);
            this.Controls.Add(this.odamount);
            this.Controls.Add(this.depoamount);
            this.Controls.Add(this.newbalamount);
            this.Name = "Withdrawal";
            this.Text = "Withdrawal";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Option;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label aname;
        private System.Windows.Forms.Label olddeposit;
        private System.Windows.Forms.Label withamount;
        private System.Windows.Forms.Label newbalance;
        private System.Windows.Forms.Label odamount;
        private System.Windows.Forms.Label depoamount;
        private System.Windows.Forms.Label newbalamount;
    }
}